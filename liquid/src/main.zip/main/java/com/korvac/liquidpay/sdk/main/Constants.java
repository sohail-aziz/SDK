package com.korvac.liquidpay.sdk.main;

/**
 * Created by sohail on 5/9/2017.
 */

final class Constants {

    //https://sandbox.api.liquidpay.com/openapi
//    public static final String BASE_URL = "https://sandbox.api.liquidpay.com/openapi/";
    public static final String BASE_URL = "https://liquidpay-dev.apigee.net/openapi/";
}
