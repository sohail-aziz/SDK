package com.korvac.liquidpay.sdk.main;

/**
 * Created by sohail on 6/7/2017.
 */

final class ErrorCodes {

    public static final String ACCESS_TOKEN_EXPIRE = "access_token_expired";

}
