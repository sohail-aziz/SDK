package com.korvac.liquidpay.sdk.main.enums;

/**
 * Card Status Values
 *
 * Created by sohail on 6/16/2017.
 */

public class CardStatus {

    public static final String ACTIVE = "A";
    public static final String PENDING = "P";

}
